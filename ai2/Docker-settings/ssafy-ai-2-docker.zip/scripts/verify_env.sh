#!/usr/bin/env bash
# ============================================================
# CH4~5 실습 환경 검증 스크립트
#   사용: docker compose run --rm <서비스명> verify_env.sh
#   빌드 성공과 런타임 정상 동작은 별개이므로 반드시 1회 실행한다.
# ============================================================
# 실패해도 끝까지 진행해야 전체 그림이 보이므로 set -e 는 쓰지 않는다.

FAIL=0
ok()   { printf '  \033[32m[OK]\033[0m   %s\n' "$1"; }
fail() { printf '  \033[31m[FAIL]\033[0m %s\n' "$1"; FAIL=1; }
warn() { printf '  \033[33m[WARN]\033[0m %s\n' "$1"; }
head1() { printf '\n\033[1m== %s ==\033[0m\n' "$1"; }

head1 '1. 인터프리터'
PYBIN=$(command -v python)
echo "  python : $PYBIN"
echo "  version: $(python -V 2>&1)"
case "$PYBIN" in
  /opt/venv/*) ok 'venv 인터프리터를 사용 중' ;;
  *)           fail "venv가 아닌 python을 사용 중 ($PYBIN). PATH 설정을 확인할 것" ;;
esac
python -c 'import sys; sys.exit(0 if sys.version_info[:2] == (3, 12) else 1)' \
  && ok 'Python 3.12' || fail "Python 3.12가 아님"

head1 '2. PyTorch / GPU'
python - <<'PY'
import sys
try:
    import torch
except Exception as e:
    print(f'  [FAIL] torch import 실패: {e}')
    sys.exit(1)

print(f'  torch        : {torch.__version__}')
print(f'  built w/ CUDA: {torch.version.cuda}')
print(f'  cuDNN        : {torch.backends.cudnn.version()}')

if not torch.cuda.is_available():
    print('  [WARN] CUDA 미인식 - GPU 없는 호스트이거나')
    print('         compose에 deploy.resources / --gpus all 설정이 빠졌을 수 있음')
    sys.exit(0)

n = torch.cuda.device_count()
print(f'  GPU 개수     : {n}')
for i in range(n):
    cap = torch.cuda.get_device_capability(i)
    mem = torch.cuda.get_device_properties(i).total_memory / 1024**3
    arch = 'Blackwell' if cap[0] >= 12 else ('Hopper' if cap[0] == 9 else 'Ampere 이하')
    print(f'    [{i}] {torch.cuda.get_device_name(i)}  sm_{cap[0]}{cap[1]}  {mem:.1f}GB  ({arch})')

# 실제 커널 실행까지 확인 (라이브러리 로딩 문제는 여기서 드러난다)
x = torch.randn(512, 512, device='cuda')
torch.cuda.synchronize()
print(f'  matmul 테스트: {(x @ x).sum().item():.2f}')
print(f'  bfloat16     : {torch.cuda.is_bf16_supported()}')
PY
[ $? -eq 0 ] && ok 'PyTorch GPU 경로 정상' || fail 'PyTorch GPU 검증 실패'

head1 '3. 양자화 / 파인튜닝 스택'
python - <<'PY'
import importlib, sys
mods = ['bitsandbytes', 'unsloth', 'unsloth_zoo', 'transformers',
        'trl', 'peft', 'accelerate', 'datasets', 'xformers', 'triton']
bad = []
for m in mods:
    try:
        mod = importlib.import_module(m)
        print(f'  {m:<14}: {getattr(mod, "__version__", "?")}')
    except Exception as e:
        print(f'  {m:<14}: import 실패 - {type(e).__name__}: {e}')
        bad.append(m)
sys.exit(1 if bad else 0)
PY
[ $? -eq 0 ] && ok '핵심 라이브러리 import 정상' || fail 'import 실패 항목 있음'

head1 '4. 4bit 양자화 스모크 테스트'
python - <<'PY'
import sys, torch
if not torch.cuda.is_available():
    print('  [SKIP] GPU 없음')
    sys.exit(0)
try:
    import bitsandbytes as bnb
    layer = bnb.nn.Linear4bit(256, 256, compute_dtype=torch.bfloat16).cuda()
    out = layer(torch.randn(4, 256, device='cuda', dtype=torch.bfloat16))
    print(f'  Linear4bit 출력 shape: {tuple(out.shape)}')
except Exception as e:
    print(f'  [FAIL] {type(e).__name__}: {e}')
    print('  => ldconfig 등록(4c 스텝) 또는 CUDA 라이브러리 경로 확인 필요')
    sys.exit(1)
PY
[ $? -eq 0 ] && ok '4bit 양자화 경로 정상' || fail '4bit 양자화 실패'

head1 '5. RAG / 도구 계층'
python - <<'PY'
import importlib, sys
mods = ['jupyterlab', 'langchain', 'langgraph', 'chromadb', 'openai',
        'pymupdf4llm', 'pandas', 'matplotlib', 'sklearn']
bad = []
for m in mods:
    try:
        importlib.import_module(m)
        print(f'  {m:<14}: ok')
    except Exception as e:
        print(f'  {m:<14}: 실패 - {type(e).__name__}')
        bad.append(m)
sys.exit(1 if bad else 0)
PY
[ $? -eq 0 ] && ok '도구 계층 정상' || fail '도구 계층 import 실패'

head1 '6. API 키 (선택)'
[ -n "$OPENAI_API_KEY" ] && ok 'OPENAI_API_KEY 설정됨' \
                         || warn 'OPENAI_API_KEY 없음 - LLM 호출 실습은 .env 필요'

echo
if [ "$FAIL" -eq 0 ]; then
  printf '\033[32m모든 검증 통과. 실습을 시작해도 좋습니다.\033[0m\n'
else
  printf '\033[31m실패 항목이 있습니다. 위 [FAIL] 로그를 확인하세요.\033[0m\n'
fi
exit $FAIL
